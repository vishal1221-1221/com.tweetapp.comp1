﻿using com.tweetapp.comp1.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace com.tweetapp.comp1.Data
{
    class ApplicationDbContext:DbContext
    {
        public ApplicationDbContext() { }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Data Source=CTSDOTNET317;Initial Catalog=TweetAppComp1Db;User ID=sa;Password=pass@word1");
                base.OnConfiguring(optionsBuilder);
        }
        public DbSet<Tweet> tweets { get; set; }
        public DbSet<UserRegistration> userRegistrations { get; set; }
    }
}
