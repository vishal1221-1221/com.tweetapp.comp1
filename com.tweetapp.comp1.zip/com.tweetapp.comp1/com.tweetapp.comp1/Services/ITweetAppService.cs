﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.tweetapp.comp1.Services
{
    interface ITweetAppService
    {
        void WelcomeBoard();
        string MainList();
        void MenuNonLoggedUser();
        string SubList();
    }
}
