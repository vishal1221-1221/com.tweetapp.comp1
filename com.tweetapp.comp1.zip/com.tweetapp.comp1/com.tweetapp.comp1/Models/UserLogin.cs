﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.tweetapp.comp1.Models
{
    class UserLogin
    {

        public string emailid { get; set; }
        public string password { get; set; }

    }
}
