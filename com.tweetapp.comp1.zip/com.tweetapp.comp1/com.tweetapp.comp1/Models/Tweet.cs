﻿using System;
using System.Collections.Generic;
using System.Text;

namespace com.tweetapp.comp1.Models
{
    class Tweet
    {
        public int TweetId { get; set; }
        public string TweetText { get; set; }
        public string EmailId { get; set; }
        public DateTime Timeofpost { get; set; }

    }
}
