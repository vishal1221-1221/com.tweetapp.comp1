﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace com.tweetapp.comp1.Models
{
    class UserRegistration
    {
        [Key]
        [Required(ErrorMessage ="Email Is Required")]
        [EmailAddress]
        public string EmailId { get; set; }

        [Required(ErrorMessage ="FirstName is Required")]
        public string FirstName { get; set; }


        [Required(ErrorMessage = "LastName is Required")]
        public string  LastName { get; set; }


        [Required(ErrorMessage = "DOB is Required")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "Gender is Required")]
        public string Gender { get; set; }
        
        [Required(ErrorMessage = "Password is Required")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public bool Active { get; set; } = false;


    }
}
