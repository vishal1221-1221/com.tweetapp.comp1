﻿using com.tweetapp.comp1.Repository;
using com.tweetapp.comp1.Services;
using Microsoft.Extensions.DependencyInjection;
using System;

namespace com.tweetapp.comp1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceCollection services = new ServiceCollection();
            Configure(services);
            IServiceProvider provider = services.BuildServiceProvider();
            var service = provider.GetService<ITweetAppService>();
            service.MenuNonLoggedUser();
        }
        private static void Configure(IServiceCollection service)
        {
            service.AddSingleton<ITweetAppRepositories, TweetAppRepositories>();
            service.AddScoped<ITweetAppService, TweetAppService>();
        }
    }
}
