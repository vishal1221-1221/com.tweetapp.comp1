﻿using com.tweetapp.comp1.Data;
using com.tweetapp.comp1.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace com.tweetapp.comp1.Repository
{
    class TweetAppRepositories:ITweetAppRepositories
    {
        public TweetAppRepositories() { }
        public UserRegistration Login(UserLogin user)
        {
            using(var appcontext=new ApplicationDbContext())
            {
                var checkuser = appcontext.userRegistrations.FirstOrDefault(c => c.EmailId == user.emailid && c.Password == user.password);
                if (checkuser != null)
                {
                    checkuser.Active = true;
                    appcontext.SaveChanges();
                    return checkuser;
                }
                else
                {
                    return null;
                }
            }

        }

        public bool Registration(UserRegistration user)
        {
            using (var appcontext = new ApplicationDbContext())
            {
                
                try
                {
                    user.Active = false;
                    appcontext.userRegistrations.Add(user);
                    appcontext.SaveChanges();
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }

        }

        public bool Logout(string emailid)
        {
            using (var appcontext = new ApplicationDbContext())
            {
                UserRegistration checkuser = appcontext.userRegistrations.FirstOrDefault(c => c.EmailId == emailid);

                if(checkuser.Active==true)
                {
                    checkuser.Active = false;
                   
                    appcontext.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }


        public bool ForgotPassword(string emailid,DateTime DOB,string newpassword)
        {
            using (var appcontext = new ApplicationDbContext())
            {
                var checkuser = appcontext.userRegistrations.FirstOrDefault(c => c.EmailId == emailid);

                if (checkuser.DOB== DOB)
                {
                    checkuser.Password = newpassword;
                    return true;

                   
                }
                else
                {
                    return false;
                }
            }

        }

        public bool ResetPassword(string emailid, string oldpassword, string newpassword)
        {
            using (var appcontext = new ApplicationDbContext())
            {
                UserRegistration checkuser = appcontext.userRegistrations.FirstOrDefault(c => c.EmailId == emailid);

                if (checkuser.Password ==oldpassword)
                {
                    checkuser.Password = newpassword;
                    appcontext.SaveChanges();
                    return true;


                }
                else
                {
                    return false;
                }
            }

        }

        public bool PostTweet(Tweet tweet)
        {
            using (var appcontext = new ApplicationDbContext())
            {
                //var checkuser = appcontext.userRegistrations.FirstOrDefault(c => c.EmailId == emailid);

               try
                {
                    appcontext.tweets.Add(tweet);
                    appcontext.SaveChanges();
                    return true;


                }
                catch(Exception)
                {
                    return false;
                }
            }

        }


        public List<Tweet>GetAllTweets()
        {
            using (var appcontext = new ApplicationDbContext())
            {
                //var checkuser = appcontext.userRegistrations.FirstOrDefault(c => c.EmailId == emailid);

                try
                {

                    return appcontext.tweets.ToList<Tweet>();


                }
                catch (Exception)
                {
                    return null;
                }
            }

        }


        public List<UserRegistration> GetAllUsers()
        {
            using (var appcontext = new ApplicationDbContext())
            {
                //var checkuser = appcontext.userRegistrations.FirstOrDefault(c => c.EmailId == emailid);

                try
                {

                    return appcontext.userRegistrations.ToList<UserRegistration>();


                }
                catch (Exception)
                {
                    return null;
                }
            }

        }

        public List<Tweet> GetUserTweets(string emailid)
        {
            using (var appcontext = new ApplicationDbContext())
            {
                var checktweet = appcontext.tweets.Where(c => c.EmailId == emailid);

                if(checktweet!=null)
                {

                    return checktweet.ToList<Tweet>();


                }
                else
                {
                    return null;
                }
            }

        }
        public bool CheckEmailExist(string emailid)
        {
            using (var appcontext = new ApplicationDbContext())
            {
               var checkuser = appcontext.userRegistrations.FirstOrDefault(c => c.EmailId == emailid);

                if (checkuser!= null)
                {
                   
                    return true;


                }
                else
                {
                    return false;
                }
            }

        }













    }
}
