﻿using com.tweetapp.comp1.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace com.tweetapp.comp1.Repository
{
    interface ITweetAppRepositories
    {
        UserRegistration Login(UserLogin user);
        bool Registration(UserRegistration NewuSer);
        bool Logout(string emailid);
        bool ForgotPassword(string emailId, DateTime DOB, string NewPassword);
        bool ResetPassword(string emailid, string OldPassword, string NewPassword);
        bool PostTweet(Tweet tweet);
        List<Tweet> GetAllTweets();
        List<UserRegistration> GetAllUsers();
        List<Tweet> GetUserTweets(string emailid);
        public bool CheckEmailExist(string emailid);

    }
}
